export default function HomePage() {
  return (
    <div className="flex items-center justify-center h-screen bg-gray-100">
      <h1 className="bg-blue-500 text-white text-4xl font-bold p-8 rounded-lg shadow-lg">
        Puchu
      </h1>
    </div>
  )
}
