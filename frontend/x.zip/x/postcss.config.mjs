// postcss.config.mjs
export default {
  plugins: {
    "@tailwindcss/postcss": {},
  },
};
